## Mesh Merge Addon - Blender 5.0 compatibility notes

What I changed (quick-fix):

* Wrapped 'import bgl' statements with a try/except so the addon can be installed in Blender 4.0+ without raising 'No module named bgl' at import time.
  This avoids the immediate import error, but does NOT fully implement the drawing functionality.

Why this is only a partial fix:

* The 'bgl' module provided raw OpenGL constants and functions (e.g., bgl.glEnable, bgl.GL\_BLEND). Blender 4.0+ removed bgl in favor of the 'gpu' module and higher-level drawing APIs.
* Simply preventing the import error will allow Blender to load the addon, but any runtime calls to 'bgl' (e.g., bgl.glEnable(...)) will fail with AttributeError unless rewritten to use 'gpu' equivalents.

Recommended modernization steps (for Blender 5.0):

1. Identify every call to bgl.\* (constants and functions).
2. Replace immediate-mode GL calls with gpu/state and gpu.types where appropriate. Example patterns:

   * bgl.glEnable(bgl.GL\_BLEND) -> from gpu import state; state.blend\_set('ALPHA')
   * bgl.glLineWidth(w) -> from gpu import state; state.line\_width\_set(w)
   * For buffer drawing, use gpu.shader.from\_builtin('3D\_UNIFORM\_COLOR') and gpu\_extras.batch.batch\_for\_shader.

3. For persistent viewport drawing handlers, use 'gpu' + 'shader' + 'batch' and register handlers via bpy.types.SpaceView3D.draw\_handler\_add with the correct 'gpu' callables.
4. Test iteratively: comment out drawing code, enable addon, then progressively replace functionality.

If you'd like, I can:

* Attempt an automated migration for simple bgl usages (enable/disable, line width, color) and update the drawing functions to use gpu + gpu\_extras.
* Or perform a manual thorough rewrite of the drawing code to follow Blender 5.0 best practices.

Location of unpacked addon directory: /mnt/data/mesh\_merge\_unpacked


**Specifically For Blender 3d version above 5.0**

